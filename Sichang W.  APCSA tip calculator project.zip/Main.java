import java.util.Scanner;  
import java.text.DecimalFormat;


class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in); 
    DecimalFormat formatter = new DecimalFormat("#.##");
 
    //this part of the code asks the user for the initial input: the number of people and the tip percent
    System.out.println("Welcome to the tip calculator, enter the number of people in your group");
    int numberOfPeople = scan.nextInt();
    System.out.println("Enter tip percentage");
    double tipPercent = scan.nextInt();
    tipPercent /= 100; //I divided the tip percent by 100 to make it a decimal that can be used in the calculations below. 
    
   
    
    double totalCost = 0;
    
    double temp = 0;

    //the while loop repeatedly asks the user to input a cost for an item, as long as the input is not -1. When the input is detected as -1, the while loop terminates. 
    while(temp != -1) {
        System.out.print("Enter the cost for each item, enter -1 to stop.");
        temp = scan.nextDouble();
        totalCost = totalCost + temp;
        
    }
        totalCost += 1; //this adds 1 to the totalCost to negate the 1 being subtracted when the user enters -1 to terminate the loop. 

    //this part of the code calculates and formats the total cost before tip, the tip, and total cost plus tip. 
    String formattedTotalCost = formatter.format(totalCost);
    System.out.println("Your total cost is " + "$" + formattedTotalCost);
    System.out.println("Your tip percentage is " + tipPercent * 100 + " percent");
    double costPlusTip = totalCost + totalCost * tipPercent;
    String formattedCostPlusTip = formatter.format(costPlusTip);
    
    double onlyTip = totalCost * tipPercent; 
    String formattedOnlyTip = formatter.format(onlyTip);
    
    
    
    
    System.out.println("your tip is " + "$" + formattedOnlyTip);
    System.out.println("your total cost plus tip is " + "$" + formattedCostPlusTip);


    //this part of the code calculates and formats the per person cost before tip, each person's tip and cost per person after tip. 
    double perPersonCostBeforeTip = totalCost / numberOfPeople;
    String formattedPPCBT = formatter.format(perPersonCostBeforeTip);
  
    
    double perPersonTip = onlyTip / numberOfPeople;
    String formattedPerPersonTip = formatter.format(perPersonTip);
  

    
    double perPersonCostAfterTip = costPlusTip / numberOfPeople; 
    String formattedPPCAT = formatter.format(perPersonCostAfterTip);

    
//this part of the code prints out all the values calculated above, with dollar signs included in string concat. 
    System.out.println("The cost per person before tip is " + "$" + formattedPPCBT);
    System.out.println("Each person paid " + "$" + formattedPerPersonTip  + " in tip" );
    System.out.println("Each person cost a total of " + "$" + formattedPPCAT + " after the tip was applied. ");
    
    
} 

    





    
    
  }
